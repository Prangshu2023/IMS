package com.nisum.ims.service;

import com.nisum.ims.dto.Customer;
import com.nisum.ims.dto.Item;
import com.nisum.ims.dto.Payment;
import com.nisum.ims.dto.Shipping;
import com.nisum.ims.entity.Order;
import com.nisum.ims.repository.OrderRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.Matchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
public class OrderServiceTest {

    @Mock
    private InventoryService inventoryService;

    @Mock
    private OrderRepository orderRepository;

    @InjectMocks
    private OrderService orderService;

    private Order order;
    private Item item;
    private Customer customer;
    private Payment payment;
    private Shipping shipping;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this); // Initialize mocks

        // Set up test data
        customer = new Customer("customer1", "John Doe", "john.doe@email.com");
        item = new Item("item1", "Product A", 5, 100.0); // Assuming 'Item' is a class
        List<Item> items = Arrays.asList(item);

        payment = new Payment("payment1", 500.0); // Assuming 'Payment' is a class
        shipping = new Shipping("shipping1", "Address XYZ"); // Assuming 'Shipping' is a class

        order = new Order("order1", customer, items, payment, shipping, "PENDING", LocalDateTime.now());
    }

    @Test
    void createOrder_shouldProcessSuccessfully() {
        // Arrange: Mocking reduceStock and save methods
        when(inventoryService.reduceStock(eq(item.getItemId()), eq(item.getQuantity())))
                .thenReturn(Mono.just(true)); // Simulating stock reduction success
        when(orderRepository.save(any(Order.class)))
                .thenReturn(Mono.just(order)); // Simulating order save success

        // Act: Call the createOrder method
        Mono<Order> result = orderService.createOrder(order);

        // Assert: Verify the interactions and result
        StepVerifier.create(result)
                .expectNextMatches(savedOrder -> savedOrder.getOrderId().equals(order.getOrderId()))
                .expectComplete()
                .verify();

        // Verify interactions with mocks
        verify(inventoryService, times(1)).reduceStock(eq(item.getItemId()), eq(item.getQuantity()));
        verify(orderRepository, times(1)).save(any(Order.class));
    }

    @Test
    void createOrder_shouldHandleInventoryFailure() {
        // Arrange: Simulate failure in reducing stock (e.g., stock not available)
        when(inventoryService.reduceStock(eq(item.getItemId()), eq(item.getQuantity())))
                .thenReturn(Mono.error(new RuntimeException("Inventory issue")));

        // Act: Call the createOrder method and expect an error
        Mono<Order> result = orderService.createOrder(order);

        // Assert: Verify the result is an error due to inventory failure
        StepVerifier.create(result)
                .expectErrorMatches(throwable -> throwable instanceof RuntimeException && throwable.getMessage().equals("Inventory issue"))
                .verify();

        // Verify that no order was saved due to inventory failure
        verify(orderRepository, times(0)).save(any(Order.class));
    }

    @Test
    void createOrder_shouldHandleSaveFailure() {
        // Arrange: Simulate successful stock reduction but failure in saving the order
        when(inventoryService.reduceStock(eq(item.getItemId()), eq(item.getQuantity())))
                .thenReturn(Mono.just(true));
        when(orderRepository.save(any(Order.class)))
                .thenReturn(Mono.error(new RuntimeException("Save failed")));

        // Act: Call the createOrder method and expect an error
        Mono<Order> result = orderService.createOrder(order);

        // Assert: Verify the result is an error due to save failure
        StepVerifier.create(result)
                .expectErrorMatches(throwable -> throwable instanceof RuntimeException && throwable.getMessage().equals("Save failed"))
                .verify();

        // Verify that reduceStock was called but save failed
        verify(inventoryService, times(1)).reduceStock(eq(item.getItemId()), eq(item.getQuantity()));
        verify(orderRepository, times(1)).save(any(Order.class));
    }
}
