package com.nisum.ims.controller;

import com.nisum.ims.dto.Customer;
import com.nisum.ims.dto.Item;
import com.nisum.ims.dto.Payment;
import com.nisum.ims.dto.Shipping;
import com.nisum.ims.entity.Order;
import com.nisum.ims.service.OrderService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import reactor.core.publisher.Mono;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.when;

public class OrderControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Mock
    private OrderService orderService;

    private Order order;
    private Item item;
    private Customer customer;
    private Payment payment;
    private Shipping shipping;

    @BeforeEach
    void setUp() {
        // Set up mock data
        customer = new Customer("customer1", "John Doe", "john.doe@email.com");
        item = new Item("item1", "Product A", 5, 100.0);
        List<Item> items = Arrays.asList(item);
        payment = new Payment("payment1", 500.0);
        shipping = new Shipping("shipping1", "Address XYZ");

        order = new Order("order1", customer, items, payment, shipping, "PENDING", LocalDateTime.now());
    }

    @Test
    void createOrder_shouldReturnOk() throws Exception {
        // Arrange: Mock the service method to return a successful order creation
        when(orderService.createOrder(any(Order.class)))
                .thenReturn(Mono.just(order));

        // Act: Perform a POST request to /createOrder
        mockMvc.perform(post("/createOrder")
                        .contentType(APPLICATION_JSON)
                        .content("{ \"orderId\": \"order1\", \"customer\": { \"customerId\": \"customer1\", \"name\": \"John Doe\" }, \"items\": [{ \"itemId\": \"item1\", \"quantity\": 5 }], \"payment\": { \"paymentId\": \"payment1\", \"amount\": 500.0 }, \"shipping\": { \"shippingId\": \"shipping1\", \"address\": \"Address XYZ\" }, \"status\": \"PENDING\" }"))
                .andExpect(status().isOk())  // Assert HTTP status 200 OK
                .andExpect(jsonPath("$.orderId").value("order1"));  // Assert that orderId is returned as expected
    }

    @Test
    void createOrder_shouldReturnError() throws Exception {
        // Arrange: Mock the service to throw an error (e.g., stock not available)
        when(orderService.createOrder(any(Order.class)))
                .thenReturn(Mono.error(new StockNotAvailableException("Stocks not available")));

        // Act: Perform the POST request
        mockMvc.perform(post("/createOrder")
                        .contentType(APPLICATION_JSON)
                        .content("{ \"orderId\": \"order1\", \"customer\": { \"customerId\": \"customer1\", \"name\": \"John Doe\" }, \"items\": [{ \"itemId\": \"item1\", \"quantity\": 5 }], \"payment\": { \"paymentId\": \"payment1\", \"amount\": 500.0 }, \"shipping\": { \"shippingId\": \"shipping1\", \"address\": \"Address XYZ\" }, \"status\": \"PENDING\" }"))
                .andExpect(status().isBadRequest())  // Assert HTTP status 400 Bad Request (for error handling)
                .andExpect(jsonPath("$.message").value("Stocks not available"));  // Assert the error message
    }
}
