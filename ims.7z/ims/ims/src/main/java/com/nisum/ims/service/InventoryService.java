package com.nisum.ims.service;

import com.nisum.ims.entity.InventoryItem;
import com.nisum.ims.exceptions.StockNotAvailableException;
import com.nisum.ims.repository.InventoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

@Service
public class InventoryService {

    private  InventoryRepository inventoryRepository;

    @Autowired
    public InventoryService(InventoryRepository inventoryRepository) {
        this.inventoryRepository = inventoryRepository;
    }


    public Mono<InventoryItem> saveInventoryItem(InventoryItem inventoryItem) {
        return inventoryRepository.save(inventoryItem)
                .onErrorResume(ex -> Mono.error(new RuntimeException("Error saving inventory item", ex)));
    }


  //save all
    public Flux<InventoryItem> saveInventoryItems(List<InventoryItem> inventoryItems) {
        return inventoryRepository.saveAll(inventoryItems)
                .onErrorResume(ex -> Flux.error(new RuntimeException("Error saving inventory item", ex)));
    }



    public Mono<InventoryItem> findInventoryItemById(String itemId) {
        return inventoryRepository.findByItemId(itemId)
                .switchIfEmpty(Mono.error(new RuntimeException("Item not found")));
    }

    public Mono<Void> reduceStock(String itemId, int quantity) {
        return inventoryRepository.findByItemId(itemId)
                .flatMap(inventoryItem -> {
                    if (inventoryItem.getStockQuantity() >= quantity) {
                        inventoryItem.setStockQuantity(inventoryItem.getStockQuantity() - quantity);
                        return inventoryRepository.save(inventoryItem).then();
                    } else {
                        return Mono.error(new StockNotAvailableException("Not enough stock for item: " + itemId));
                    }
                });
    }


}
