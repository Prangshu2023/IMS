package com.nisum.ims.controller;

import com.nisum.ims.entity.InventoryItem;
import com.nisum.ims.service.InventoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

@RestController
@RequestMapping("/inventory")
public class InventoryController {

    @Autowired
    private InventoryService inventoryService;

    // Save inventory item
    @PostMapping("/save")
    public Mono<InventoryItem> saveInventoryItem(@RequestBody InventoryItem inventoryItem) {
        return inventoryService.saveInventoryItem(inventoryItem);
    }
    //save multiple items
    @PostMapping("/saveMultipleItem")
    public Flux<InventoryItem> saveInventoryItems(@RequestBody List<InventoryItem> inventoryItems) {
        // Save all inventory items reactively
        return inventoryService.saveInventoryItems(inventoryItems);
    }

    // Get an inventory item by itemId
    @GetMapping("/{itemId}")
    public Mono<InventoryItem> getInventoryItemById(@PathVariable String itemId) {
        return inventoryService.findInventoryItemById(itemId);
    }
}
