package com.nisum.ims.repository;

import com.nisum.ims.entity.Order;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;
@Repository
public interface OrderRepository extends ReactiveMongoRepository<Order,String> {
    Mono<Order> findByOrderId(String orderId);
}
