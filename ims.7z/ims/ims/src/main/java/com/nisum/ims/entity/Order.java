package com.nisum.ims.entity;

import com.nisum.ims.dto.Customer;
import com.nisum.ims.dto.Item;
import com.nisum.ims.dto.Payment;
import com.nisum.ims.dto.Shipping;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.List;
/*@Data
@AllArgsConstructor
@NoArgsConstructor*/

@Document(collection = "orders")
public class Order {
    @Id
    private String orderId;
    private Customer customer;
    private List<Item> items;
    private Payment payment;
    private Shipping shipping;
    private String status;
    private LocalDateTime createdAt;

    public Order(String orderId) {
        this.orderId = orderId;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public List<Item> getItems() {
        return items;
    }

    public void setItems(List<Item> items) {
        this.items = items;
    }

    public Payment getPayment() {
        return payment;
    }

    public void setPayment(Payment payment) {
        this.payment = payment;
    }

    public Shipping getShipping() {
        return shipping;
    }

    public void setShipping(Shipping shipping) {
        this.shipping = shipping;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
