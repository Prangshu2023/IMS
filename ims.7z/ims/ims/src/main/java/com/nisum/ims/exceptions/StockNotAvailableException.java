package com.nisum.ims.exceptions;

public class StockNotAvailableException extends RuntimeException{
    public StockNotAvailableException(String message) {
        super(message);
    }
}
