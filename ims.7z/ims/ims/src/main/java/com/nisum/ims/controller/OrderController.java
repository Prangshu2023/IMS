package com.nisum.ims.controller;

import com.nisum.ims.entity.Order;
import com.nisum.ims.exceptions.StockNotAvailableException;
import com.nisum.ims.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/orders")
public class OrderController {

    private final OrderService orderService;

    @Autowired
    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }


    @PostMapping("/createOrder")
    public Mono<Order> createOrder(@RequestBody Order order) {
        return orderService.createOrder(order).
        onErrorResume(Exception.class, e -> {
            // Catch all exceptions and throw a StockNotAvailableException
            return Mono.error(new StockNotAvailableException("Stocks not available or some other issue: " + e.getMessage()));
    });


}
}
