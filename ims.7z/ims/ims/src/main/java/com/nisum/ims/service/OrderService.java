package com.nisum.ims.service;

import com.nisum.ims.entity.Order;
import com.nisum.ims.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
@Service
public class OrderService {
    private final InventoryService inventoryService;
    private final OrderRepository orderRepository;

    @Autowired
    public OrderService(InventoryService inventoryService, OrderRepository orderRepository) {
        this.inventoryService = inventoryService;
        this.orderRepository = orderRepository;
    }

    public Mono<Order> createOrder(Order order) {
        return Flux.fromIterable(order.getItems())
                .flatMap(item -> inventoryService.reduceStock(item.getItemId(), item.getQuantity()))
                .then(orderRepository.save(order));
    }
}
